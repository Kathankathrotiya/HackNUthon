from flask import Flask, request, render_template
import mysql.connector

app=Flask(__name__)

db=mysql.connector.connect(
    database="hackathon",
    host="localhost",
    user="root",
    password="kathan"
)

cursor = db.cursor()
@app.route('/', methods=['GET'])
def index():
    return render_template('First.html')

@app.route('/usermain')
def usermain():
    return render_template('usermain.html')

@app.route('/BusinessRegistration')
def regs():
    return render_template('BusinessRegistration.html')

# @app.route('/login2')
# def regs():
#     return render_template('login2.html')

@app.route('/bussiness')
def bussiness():
    return render_template('bussiness.html')


@app.route('/register',methods=['GET','POST'])
def register():
    if request.method == "POST":
        sql = "INSERT INTO data (`fname`, `lname`, `email`, `Mno`) VALUES (%s, %s, %s, %s)"
        val = (
            request.form["fname"],
            request.form["lname"],
            request.form["email"],
            request.form["MNo"],
        )
        try:
            cursor.execute(sql,val)
        except Exception as e:
            print(e)
        db.commit()
        # return render_template("index.html", results=["Query executed successfully"])
    return render_template("register.html")

id=""
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email1']
        passw=request.form["pass"]
        # butt=request.form["Hello"]
        # print(butt)
        sql = "SELECT password FROM   data WHERE email = %s"
        try:
            cursor.execute(sql, (email,))
            fet = cursor.fetchall()
            print(fet)
            if str(fet[0][0]) == passw:
                global id
                id=email
                print(id)
                return render_template('PrivateBusinessMain.html')
            else:
                return render_template('login.html', message="Invalid Password")
        except Exception as e:
            print(e)
            return render_template('login.html', message=f'Error: {e}')
    return render_template('login.html')

@app.route('/login2', methods=['GET', 'POST'])
def login2():
    if request.method == 'POST':
        email = request.form['email1']
        passw=request.form["pass"]
        # butt=request.form["Hello"]
        # print(butt)
        sql = "SELECT password FROM   data WHERE email = %s"
        try:
            cursor.execute(sql, (email,))
            fet = cursor.fetchall()
            print(fet)
            if str(fet[0][0]) == passw:
                global id
                id=email
                print(id)
                # return render_template('PrivateBusinessMain.html')
            else:
                return render_template('login2.html', message="Invalid Password")
        except Exception as e:
            print(e)
            return render_template('login2.html', message=f'Error: {e}')
    return render_template('login2.html')

@app.route('/buss',methods=['GET','POST'])
def pvtbuss():
    if request.method=="GET":
        sql="select cname from databusi"
        try:
            cursor.execute(sql)
            fet = cursor.fetchall()
        except Exception as e:
            print(e)
        options = [(row[0], row[0]) for row in fet]
        print(fet)
        return render_template('PrivateBusinessMain.html', options=options)
    if request.method=="POST":
        type=request.form["bussi"]
        slot=request.form["time"]
        print(id)
        sql="insert into combine values(%s,%s,%s,%s)"
        return render_template('PrivateBusinessMain.html',options=options)


@app.route('/registerbusi',methods=['GET','POST'])
def registerbusi():
    if request.method == "POST":
        sql = "INSERT INTO   data (`fname`, `lname`, `email`, `Mno`,`cname`,`bcate`,`city`) VALUES (%s, %s, %s, %s, %s, %s, %s)"
        val = (
            request.form["fname"],
            request.form["lname"],
            request.form["email"],
            request.form["MNo"],
            request.form["cname"],
            request.form["bcate"],
            request.form["city"],
        )
        try:
            cursor.execute(sql,val)
        except Exception as e:
            print(e)
        db.commit()
        # return render_template("index.html", results=["Query executed successfully"])
    return render_template("BusinessRegistration.html")
# id=""
# @app.route('/login', methods=['GET', 'POST'])
# def login():
#     if request.method == 'POST':
#         email = request.form['email1']
#         passw=request.form["pass"]
#         # butt=request.form["Hello"]
#         # print(butt)
#         sql = "SELECT password FROM   data WHERE email = %s"
#         try:
#             cursor.execute(sql, (email,))
#             fet = cursor.fetchall()
#             print(fet)
#             if str(fet[0][0]) == passw:
#                 global id
#                 id=email
#                 print(id)
#                 return render_template('PrivateBusinessMain.html')
#             else:
#                 return render_template('login.html', message="Invalid Password")
#         except Exception as e:
#             print(e)
#             return render_template('login.html', message=f'Error: {e}')
#     return render_template('login.html')


def insert_data():
    # pass
    # cursor.execute("create database temp")
    # cursor.execute("create table data(fname varchar(255) not null,lname varchar(255) not null,email varchar(255) primary key,Mno varchar(10) check(length(Mno)=10))")
    cursor.execute("alter table data add column password varchar(255)")
    # cursor.execute("Delete from data where fname='Het'")
    # cursor.execute("create table databusi(fname varchar(255) not null,lname varchar(255) not null,email varchar(255) primary key,Mno varchar(10) check(length(Mno)=10) not null,cname varchar(255) not null,bcate varchar(255) not null,city varchar(255) not null)")
    # cursor.execute("drop table databusi")
#     cursor.execute("CREATE TABLE combine (\
#     P1 varchar(255) NOT NULL,\
#     P2 varchar(255) NOT NULL,\
#     bcate varchar(255),\
#     slot varchar(255) not null,\
#    PRIMARY KEY (P1, P2),\
#    FOREIGN KEY (P1) REFERENCES data (email),\
#    FOREIGN KEY (P2) REFERENCES databusi (email))")


if __name__=='__main__':
    # insert_data()
    app.run(debug=True)